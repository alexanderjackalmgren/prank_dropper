On Error Resume Next
' 20 minute delay (20 * 60 * 1000 milliseconds)
WScript.Sleep 900000 

Set oPlayer = CreateObject("WMPlayer.OCX")

' Link to the MP3
oPlayer.URL = "C:\temp\file.mp3"
oPlayer.controls.play

' Stay alive in RAM until the music finishes
While oPlayer.playState <> 1
    WScript.Sleep 1000
Wend